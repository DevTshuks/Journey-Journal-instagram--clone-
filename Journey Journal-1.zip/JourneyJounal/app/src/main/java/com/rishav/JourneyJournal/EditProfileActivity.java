package com.rishav.JourneyJournal;

import android.app.Activity;

public class EditProfileActivity extends Activity {
}
